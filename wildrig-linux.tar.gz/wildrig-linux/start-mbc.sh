#!/bin/bash

while true
do
./wildrig-multi --print-full --max-rejects 50 --algo rainforest --opencl-threads auto --opencl-launch auto --url stratum+tcp://mbc.altpool.pro:6222 --user Brbt9PGVSRoYsi6vrynDF3b3heceYHUf2G --pass c=MBC
sleep 5
done
